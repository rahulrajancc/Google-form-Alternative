
  # Hyperlocal Shop Discovery App

  This is a code bundle for Hyperlocal Shop Discovery App. The original project is available at https://www.figma.com/design/mSe5nqlfgjOdXK4JUY3Sg4/Hyperlocal-Shop-Discovery-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  