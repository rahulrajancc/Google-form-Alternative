import { ArrowLeft, Phone, MapPin, CheckCircle, XCircle, HelpCircle } from 'lucide-react';

interface SearchResultsScreenProps {
  searchQuery: string;
  onBack: () => void;
  onItemClick: (item: string) => void;
}

const mockShops = [
  {
    id: 1,
    name: 'Rajesh Provision Store',
    distance: '0.3 km',
    status: 'available',
    phone: '+91 98765 43210',
    whatsapp: '+91 98765 43210',
  },
  {
    id: 2,
    name: 'Modern General Store',
    distance: '0.5 km',
    status: 'not-sure',
    phone: '+91 98765 43211',
    whatsapp: '+91 98765 43211',
  },
  {
    id: 3,
    name: 'City Supermarket',
    distance: '0.8 km',
    status: 'available',
    phone: '+91 98765 43212',
    whatsapp: '+91 98765 43212',
  },
  {
    id: 4,
    name: 'Quick Mart',
    distance: '1.2 km',
    status: 'out-of-stock',
    phone: '+91 98765 43213',
    whatsapp: '+91 98765 43213',
  },
  {
    id: 5,
    name: 'Local Bazaar',
    distance: '1.5 km',
    status: 'available',
    phone: '+91 98765 43214',
    whatsapp: '+91 98765 43214',
  },
];

export default function SearchResultsScreen({
  searchQuery,
  onBack,
  onItemClick,
}: SearchResultsScreenProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'available':
        return (
          <div className="flex items-center gap-1 px-3 py-1 bg-green-50 text-green-700 rounded-full">
            <CheckCircle size={16} />
            <span>Available</span>
          </div>
        );
      case 'out-of-stock':
        return (
          <div className="flex items-center gap-1 px-3 py-1 bg-red-50 text-red-700 rounded-full">
            <XCircle size={16} />
            <span>Out of Stock</span>
          </div>
        );
      default:
        return (
          <div className="flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-600 rounded-full">
            <HelpCircle size={16} />
            <span>Not Sure</span>
          </div>
        );
    }
  };

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
  };

  const handleWhatsApp = (phone: string) => {
    window.open(`https://wa.me/${phone.replace(/[^0-9]/g, '')}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-200 p-4">
        <div className="flex items-center gap-3 mb-3">
          <button onClick={onBack} className="p-2 -ml-2 hover:bg-gray-100 rounded-lg">
            <ArrowLeft size={24} />
          </button>
          <h2>Search Results</h2>
        </div>
        <div className="text-gray-600">
          Showing results for: <span className="text-blue-600">{searchQuery}</span>
        </div>
        <button
          onClick={() => onItemClick(searchQuery)}
          className="mt-3 text-blue-600 hover:underline"
        >
          View item details →
        </button>
      </div>

      {/* Shop List */}
      <div className="p-4 space-y-4">
        {mockShops.map((shop) => (
          <div
            key={shop.id}
            className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <h3 className="mb-1">{shop.name}</h3>
                <div className="flex items-center gap-1 text-gray-500">
                  <MapPin size={16} />
                  <span>{shop.distance} away</span>
                </div>
              </div>
              {getStatusBadge(shop.status)}
            </div>

            {/* Contact Buttons */}
            <div className="flex gap-3">
              <button
                onClick={() => handleCall(shop.phone)}
                className="flex-1 flex items-center justify-center gap-2 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
              >
                <Phone size={18} />
                <span>Call</span>
              </button>
              <button
                onClick={() => handleWhatsApp(shop.whatsapp)}
                className="flex-1 flex items-center justify-center gap-2 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600"
              >
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  className="flex-shrink-0"
                >
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
                <span>WhatsApp</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
