import { ArrowLeft, MapPin, Briefcase, Phone, Lock } from 'lucide-react';

interface JobListingsScreenProps {
  onBack: () => void;
}

const mockJobs = [
  {
    id: 1,
    title: 'Shop Assistant',
    shopName: 'Rajesh Provision Store',
    location: 'Koramangala',
    distance: '0.3 km',
    salary: '₹12,000 - ₹15,000/month',
    type: 'Full Time',
    isPremium: false,
    phone: '+91 98765 43210',
  },
  {
    id: 2,
    title: 'Delivery Person',
    shopName: 'City Supermarket',
    location: 'Indiranagar',
    distance: '0.8 km',
    salary: '₹10,000 - ₹12,000/month',
    type: 'Full Time',
    isPremium: true,
    phone: '+91 98765 43212',
  },
  {
    id: 3,
    title: 'Sales Executive',
    shopName: 'Modern General Store',
    location: 'Koramangala',
    distance: '0.5 km',
    salary: '₹15,000 - ₹18,000/month',
    type: 'Full Time',
    isPremium: false,
    phone: '+91 98765 43211',
  },
  {
    id: 4,
    title: 'Store Manager',
    shopName: 'Quick Mart',
    location: 'HSR Layout',
    distance: '1.2 km',
    salary: '₹20,000 - ₹25,000/month',
    type: 'Full Time',
    isPremium: true,
    phone: '+91 98765 43213',
  },
];

export default function JobListingsScreen({ onBack }: JobListingsScreenProps) {
  const handleContactShop = (phone: string, isPremium: boolean) => {
    if (isPremium) {
      alert('Premium feature: Please upgrade to contact this shop owner');
      return;
    }
    window.location.href = `tel:${phone}`;
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-200 p-4">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 -ml-2 hover:bg-gray-100 rounded-lg">
            <ArrowLeft size={24} />
          </button>
          <h2>Job Listings</h2>
        </div>
      </div>

      {/* Info Banner */}
      <div className="p-4 bg-green-50 border-b border-green-100">
        <p className="text-sm text-green-800">
          Browse jobs for free. Contact shop owners directly for application.
        </p>
      </div>

      {/* Job List */}
      <div className="p-4 space-y-4">
        {mockJobs.map((job) => (
          <div key={job.id} className="p-4 border border-gray-200 rounded-lg">
            {/* Premium Badge */}
            {job.isPremium && (
              <div className="inline-flex items-center gap-1 px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-sm mb-3">
                <Lock size={14} />
                <span>Premium</span>
              </div>
            )}

            <div className="flex items-start gap-3 mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Briefcase size={24} className="text-blue-600" />
              </div>
              <div className="flex-1">
                <h3 className="mb-1">{job.title}</h3>
                <div className="text-gray-600">{job.shopName}</div>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-gray-600">
                <MapPin size={16} />
                <span>
                  {job.location} • {job.distance}
                </span>
              </div>
              <div className="text-green-600">{job.salary}</div>
              <div className="inline-block px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                {job.type}
              </div>
            </div>

            <button
              onClick={() => handleContactShop(job.phone, job.isPremium)}
              className={`w-full flex items-center justify-center gap-2 py-3 rounded-lg ${
                job.isPremium
                  ? 'bg-yellow-100 text-yellow-800 border border-yellow-300 hover:bg-yellow-200'
                  : 'bg-blue-500 text-white hover:bg-blue-600'
              }`}
            >
              {job.isPremium ? (
                <>
                  <Lock size={18} />
                  <span>Unlock Contact</span>
                </>
              ) : (
                <>
                  <Phone size={18} />
                  <span>Contact Shop Owner</span>
                </>
              )}
            </button>
          </div>
        ))}
      </div>

      {/* Upgrade CTA */}
      <div className="p-4 m-4 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg">
        <h3 className="mb-2">Upgrade to Premium</h3>
        <p className="text-sm text-blue-100 mb-4">
          Get access to all job listings and contact shop owners directly
        </p>
        <button className="w-full py-3 bg-white text-blue-600 rounded-lg hover:bg-blue-50">
          Upgrade Now
        </button>
      </div>
    </div>
  );
}
