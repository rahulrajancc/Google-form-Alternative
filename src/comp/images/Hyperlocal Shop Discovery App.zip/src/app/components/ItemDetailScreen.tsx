import { ArrowLeft, Store, MapPin, Phone } from 'lucide-react';

interface ItemDetailScreenProps {
  itemName: string;
  onBack: () => void;
  onReserve: () => void;
}

const mockItemDetails = {
  priceRange: '₹50 - ₹150',
  description: 'Fresh and locally sourced',
  availableShops: [
    {
      id: 1,
      name: 'Rajesh Provision Store',
      price: '₹50',
      distance: '0.3 km',
      phone: '+91 98765 43210',
    },
    {
      id: 2,
      name: 'City Supermarket',
      price: '₹75',
      distance: '0.8 km',
      phone: '+91 98765 43212',
    },
    {
      id: 3,
      name: 'Local Bazaar',
      price: '₹60',
      distance: '1.5 km',
      phone: '+91 98765 43214',
    },
  ],
};

export default function ItemDetailScreen({ itemName, onBack, onReserve }: ItemDetailScreenProps) {
  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-200 p-4">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 -ml-2 hover:bg-gray-100 rounded-lg">
            <ArrowLeft size={24} />
          </button>
          <h2>Item Details</h2>
        </div>
      </div>

      {/* Item Info */}
      <div className="p-6 border-b border-gray-200">
        <h1 className="mb-3">{itemName}</h1>
        <div className="mb-2">
          <div className="text-gray-600 mb-1">Price Range</div>
          <div className="text-blue-600">{mockItemDetails.priceRange}</div>
        </div>
        <div className="text-gray-600">{mockItemDetails.description}</div>
      </div>

      {/* Available Shops */}
      <div className="p-4">
        <h3 className="mb-4 text-gray-700">
          Available at {mockItemDetails.availableShops.length} shops
        </h3>

        <div className="space-y-3">
          {mockItemDetails.availableShops.map((shop) => (
            <div key={shop.id} className="p-4 border border-gray-200 rounded-lg">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Store size={18} className="text-gray-500" />
                    <h4>{shop.name}</h4>
                  </div>
                  <div className="flex items-center gap-1 text-gray-500 mb-2">
                    <MapPin size={16} />
                    <span>{shop.distance} away</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-green-600">{shop.price}</div>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => handleCall(shop.phone)}
                  className="flex-1 flex items-center justify-center gap-2 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                >
                  <Phone size={18} />
                  <span>Call Shop</span>
                </button>
                <button
                  onClick={onReserve}
                  className="flex-1 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600"
                >
                  Reserve
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
