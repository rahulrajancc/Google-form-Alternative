import { useState } from 'react';
import { ArrowLeft, Plus, Search } from 'lucide-react';

interface InventoryUploadScreenProps {
  onBack: () => void;
}

interface InventoryItem {
  id: number;
  name: string;
  category: string;
  available: boolean;
  price?: string;
}

export default function InventoryUploadScreen({ onBack }: InventoryUploadScreenProps) {
  const [items, setItems] = useState<InventoryItem[]>([
    { id: 1, name: 'Fresh Vegetables', category: 'Produce', available: true, price: '₹50' },
    { id: 2, name: 'Rice (1kg)', category: 'Grains', available: true, price: '₹60' },
    { id: 3, name: 'Milk (1L)', category: 'Dairy', available: false, price: '₹55' },
    { id: 4, name: 'Bread', category: 'Bakery', available: true, price: '₹40' },
    { id: 5, name: 'Eggs (12 pcs)', category: 'Dairy', available: true, price: '₹84' },
  ]);

  const [showAddForm, setShowAddForm] = useState(false);
  const [newItemName, setNewItemName] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const toggleAvailability = (id: number) => {
    setItems(
      items.map((item) =>
        item.id === id ? { ...item, available: !item.available } : item
      )
    );
  };

  const addNewItem = () => {
    if (newItemName.trim()) {
      const newItem: InventoryItem = {
        id: Date.now(),
        name: newItemName,
        category: 'General',
        available: true,
        price: '',
      };
      setItems([...items, newItem]);
      setNewItemName('');
      setShowAddForm(false);
    }
  };

  const filteredItems = items.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-200 p-4 z-10">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onBack} className="p-2 -ml-2 hover:bg-gray-100 rounded-lg">
            <ArrowLeft size={24} />
          </button>
          <h2>Manage Inventory</h2>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <input
            type="text"
            placeholder="Search items..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:border-green-500"
          />
          <Search
            size={18}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
          />
        </div>
      </div>

      {/* Stats */}
      <div className="p-4 bg-green-50 border-b border-green-100">
        <div className="flex justify-around text-center">
          <div>
            <div className="text-green-600">{items.length}</div>
            <div className="text-xs text-gray-600">Total Items</div>
          </div>
          <div>
            <div className="text-green-600">
              {items.filter((item) => item.available).length}
            </div>
            <div className="text-xs text-gray-600">Available</div>
          </div>
          <div>
            <div className="text-red-600">
              {items.filter((item) => !item.available).length}
            </div>
            <div className="text-xs text-gray-600">Out of Stock</div>
          </div>
        </div>
      </div>

      {/* Add New Item Form */}
      {showAddForm && (
        <div className="p-4 bg-blue-50 border-b border-blue-100">
          <h4 className="mb-3">Add New Item</h4>
          <input
            type="text"
            placeholder="Item name"
            value={newItemName}
            onChange={(e) => setNewItemName(e.target.value)}
            className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:border-green-500 mb-3"
          />
          <div className="flex gap-3">
            <button
              onClick={addNewItem}
              className="flex-1 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600"
            >
              Add Item
            </button>
            <button
              onClick={() => setShowAddForm(false)}
              className="flex-1 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Item List */}
      <div className="p-4 space-y-3">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h4 className="mb-1">{item.name}</h4>
                <div className="text-sm text-gray-500 mb-1">{item.category}</div>
                {item.price && <div className="text-green-600">{item.price}</div>}
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div
                    className={`text-sm mb-1 ${
                      item.available ? 'text-green-600' : 'text-red-600'
                    }`}
                  >
                    {item.available ? 'Available' : 'Out of Stock'}
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={item.available}
                    onChange={() => toggleAvailability(item.id)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
                </label>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Button */}
      <button
        onClick={() => setShowAddForm(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-green-500 text-white rounded-full shadow-lg hover:bg-green-600 flex items-center justify-center"
      >
        <Plus size={24} />
      </button>
    </div>
  );
}
