import { Package, Briefcase, Bell, Store, MapPin, Tag } from 'lucide-react';

interface ShopOwnerOnboardingProps {
  onInventoryClick: () => void;
  onJobPostClick: () => void;
  onRequestsClick: () => void;
}

export default function ShopOwnerOnboarding({
  onInventoryClick,
  onJobPostClick,
  onRequestsClick,
}: ShopOwnerOnboardingProps) {
  const shopInfo = {
    name: 'Rajesh Provision Store',
    category: 'Grocery & Provisions',
    location: 'Koramangala, Bangalore',
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-green-500 text-white p-6 pb-8">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <Store size={24} />
          </div>
          <div>
            <div className="text-sm opacity-90">Welcome back</div>
            <h2 className="text-white">{shopInfo.name}</h2>
          </div>
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2">
            <Tag size={16} />
            <span>{shopInfo.category}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin size={16} />
            <span>{shopInfo.location}</span>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-4 p-6 -mt-6">
        <div className="bg-white p-4 rounded-lg shadow-md border border-gray-100 text-center">
          <div className="text-green-600 mb-1">125</div>
          <div className="text-xs text-gray-600">Items Listed</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow-md border border-gray-100 text-center">
          <div className="text-blue-600 mb-1">8</div>
          <div className="text-xs text-gray-600">Reservations</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow-md border border-gray-100 text-center">
          <div className="text-yellow-600 mb-1">3</div>
          <div className="text-xs text-gray-600">Active Jobs</div>
        </div>
      </div>

      {/* Main Actions */}
      <div className="p-6 space-y-4">
        <h3 className="text-gray-700 mb-4">Manage Your Shop</h3>

        {/* Inventory Management */}
        <button
          onClick={onInventoryClick}
          className="w-full p-5 bg-white border-2 border-gray-200 rounded-lg hover:border-green-500 hover:bg-green-50 text-left transition-colors"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Package size={24} className="text-green-600" />
            </div>
            <div className="flex-1">
              <h4 className="mb-1">Manage Inventory</h4>
              <p className="text-sm text-gray-600">
                Add or update item availability
              </p>
            </div>
          </div>
        </button>

        {/* Reservation Requests */}
        <button
          onClick={onRequestsClick}
          className="w-full p-5 bg-white border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 text-left transition-colors"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Bell size={24} className="text-blue-600" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h4>Reservation Requests</h4>
                <span className="px-2 py-0.5 bg-red-500 text-white text-xs rounded-full">
                  3
                </span>
              </div>
              <p className="text-sm text-gray-600">
                View and manage customer reservations
              </p>
            </div>
          </div>
        </button>

        {/* Job Postings */}
        <button
          onClick={onJobPostClick}
          className="w-full p-5 bg-white border-2 border-gray-200 rounded-lg hover:border-yellow-500 hover:bg-yellow-50 text-left transition-colors"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Briefcase size={24} className="text-yellow-600" />
            </div>
            <div className="flex-1">
              <h4 className="mb-1">Post a Job</h4>
              <p className="text-sm text-gray-600">
                Hire staff for your shop
              </p>
            </div>
          </div>
        </button>
      </div>

      {/* Help Section */}
      <div className="p-6 m-6 bg-gray-50 rounded-lg border border-gray-200">
        <h4 className="mb-2">Need Help?</h4>
        <p className="text-sm text-gray-600 mb-4">
          Contact our support team for assistance
        </p>
        <button className="w-full py-3 bg-green-500 text-white rounded-lg hover:bg-green-600">
          Contact Support
        </button>
      </div>
    </div>
  );
}
