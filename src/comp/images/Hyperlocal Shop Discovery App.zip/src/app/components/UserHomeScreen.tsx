import { useState } from 'react';
import { Search, MapPin, Briefcase } from 'lucide-react';

interface UserHomeScreenProps {
  onSearch: (query: string) => void;
  onJobsClick: () => void;
}

export default function UserHomeScreen({ onSearch, onJobsClick }: UserHomeScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [location, setLocation] = useState('Koramangala, Bangalore');

  const popularSearches = [
    'Fresh Vegetables',
    'Printer Ink',
    'Birthday Cake',
    'Mobile Accessories',
    'Medicine',
    'Hardware Tools',
  ];

  const handleSearch = () => {
    if (searchQuery.trim()) {
      onSearch(searchQuery);
    }
  };

  return (
    <div className="min-h-screen bg-white p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="mb-2">Find Local Shops</h1>
        <p className="text-gray-500">Discover items available nearby</p>
      </div>

      {/* Location Selector */}
      <div className="mb-6">
        <button className="w-full flex items-center gap-3 p-4 bg-gray-50 rounded-lg border border-gray-200">
          <MapPin size={20} className="text-blue-500 flex-shrink-0" />
          <div className="flex-1 text-left">
            <div className="text-sm text-gray-500">Your Location</div>
            <div>{location}</div>
          </div>
        </button>
      </div>

      {/* Search Bar */}
      <div className="mb-8">
        <div className="relative">
          <input
            type="text"
            placeholder="Search item near you"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-blue-500"
          />
          <Search
            size={20}
            className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"
          />
        </div>
        <button
          onClick={handleSearch}
          className="w-full mt-3 py-4 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
        >
          Search
        </button>
      </div>

      {/* Popular Searches */}
      <div className="mb-8">
        <h3 className="mb-4 text-gray-700">Popular Searches</h3>
        <div className="grid grid-cols-2 gap-3">
          {popularSearches.map((item) => (
            <button
              key={item}
              onClick={() => onSearch(item)}
              className="p-4 bg-white border border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 text-left"
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      {/* Jobs Button */}
      <button
        onClick={onJobsClick}
        className="w-full flex items-center justify-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg hover:bg-green-100"
      >
        <Briefcase size={20} className="text-green-600" />
        <span className="text-green-700">View Job Listings</span>
      </button>
    </div>
  );
}
