import { useState } from 'react';
import { ArrowLeft, Phone, User, Clock, CheckCircle, XCircle } from 'lucide-react';

interface ReservationRequestsScreenProps {
  onBack: () => void;
}

interface Reservation {
  id: number;
  customerName: string;
  customerPhone: string;
  item: string;
  time: string;
  status: 'pending' | 'accepted' | 'rejected';
}

export default function ReservationRequestsScreen({ onBack }: ReservationRequestsScreenProps) {
  const [reservations, setReservations] = useState<Reservation[]>([
    {
      id: 1,
      customerName: 'Priya Sharma',
      customerPhone: '+91 98765 00001',
      item: 'Fresh Vegetables',
      time: '10 mins ago',
      status: 'pending',
    },
    {
      id: 2,
      customerName: 'Amit Kumar',
      customerPhone: '+91 98765 00002',
      item: 'Rice (1kg)',
      time: '25 mins ago',
      status: 'pending',
    },
    {
      id: 3,
      customerName: 'Sneha Reddy',
      customerPhone: '+91 98765 00003',
      item: 'Bread',
      time: '1 hour ago',
      status: 'pending',
    },
    {
      id: 4,
      customerName: 'Rahul Patel',
      customerPhone: '+91 98765 00004',
      item: 'Milk (1L)',
      time: '2 hours ago',
      status: 'accepted',
    },
    {
      id: 5,
      customerName: 'Kavita Singh',
      customerPhone: '+91 98765 00005',
      item: 'Eggs (12 pcs)',
      time: '3 hours ago',
      status: 'rejected',
    },
  ]);

  const handleAccept = (id: number) => {
    setReservations(
      reservations.map((res) => (res.id === id ? { ...res, status: 'accepted' } : res))
    );
  };

  const handleReject = (id: number) => {
    setReservations(
      reservations.map((res) => (res.id === id ? { ...res, status: 'rejected' } : res))
    );
  };

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
  };

  const pendingCount = reservations.filter((r) => r.status === 'pending').length;
  const acceptedCount = reservations.filter((r) => r.status === 'accepted').length;

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-200 p-4 z-10">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onBack} className="p-2 -ml-2 hover:bg-gray-100 rounded-lg">
            <ArrowLeft size={24} />
          </button>
          <h2>Reservation Requests</h2>
        </div>
      </div>

      {/* Stats */}
      <div className="p-4 bg-blue-50 border-b border-blue-100">
        <div className="flex justify-around text-center">
          <div>
            <div className="text-blue-600">{reservations.length}</div>
            <div className="text-xs text-gray-600">Total Requests</div>
          </div>
          <div>
            <div className="text-yellow-600">{pendingCount}</div>
            <div className="text-xs text-gray-600">Pending</div>
          </div>
          <div>
            <div className="text-green-600">{acceptedCount}</div>
            <div className="text-xs text-gray-600">Accepted</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200">
        <button className="flex-1 py-3 border-b-2 border-blue-500">All Requests</button>
      </div>

      {/* Requests List */}
      <div className="p-4 space-y-4">
        {reservations.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            No reservation requests yet
          </div>
        ) : (
          reservations.map((reservation) => (
            <div
              key={reservation.id}
              className={`p-4 border rounded-lg ${
                reservation.status === 'pending'
                  ? 'border-yellow-200 bg-yellow-50'
                  : reservation.status === 'accepted'
                  ? 'border-green-200 bg-green-50'
                  : 'border-gray-200 bg-gray-50'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <User size={20} className="text-blue-600" />
                  </div>
                  <div>
                    <h4 className="mb-1">{reservation.customerName}</h4>
                    <div className="text-sm text-gray-600 mb-1">
                      Wants to reserve: <span className="text-blue-600">{reservation.item}</span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      <Clock size={14} />
                      <span>{reservation.time}</span>
                    </div>
                  </div>
                </div>

                {/* Status Badge */}
                {reservation.status === 'accepted' && (
                  <div className="flex items-center gap-1 px-2 py-1 bg-green-100 text-green-700 rounded text-sm">
                    <CheckCircle size={14} />
                    <span>Accepted</span>
                  </div>
                )}
                {reservation.status === 'rejected' && (
                  <div className="flex items-center gap-1 px-2 py-1 bg-gray-200 text-gray-700 rounded text-sm">
                    <XCircle size={14} />
                    <span>Rejected</span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              {reservation.status === 'pending' ? (
                <div className="flex gap-3">
                  <button
                    onClick={() => handleCall(reservation.customerPhone)}
                    className="flex-1 flex items-center justify-center gap-2 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                  >
                    <Phone size={18} />
                    <span>Call</span>
                  </button>
                  <button
                    onClick={() => handleAccept(reservation.id)}
                    className="flex-1 flex items-center justify-center gap-2 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600"
                  >
                    <CheckCircle size={18} />
                    <span>Accept</span>
                  </button>
                  <button
                    onClick={() => handleReject(reservation.id)}
                    className="flex-1 flex items-center justify-center gap-2 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600"
                  >
                    <XCircle size={18} />
                    <span>Reject</span>
                  </button>
                </div>
              ) : reservation.status === 'accepted' ? (
                <button
                  onClick={() => handleCall(reservation.customerPhone)}
                  className="w-full flex items-center justify-center gap-2 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                >
                  <Phone size={18} />
                  <span>Call Customer</span>
                </button>
              ) : (
                <div className="text-center text-gray-500 py-2">Request rejected</div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
