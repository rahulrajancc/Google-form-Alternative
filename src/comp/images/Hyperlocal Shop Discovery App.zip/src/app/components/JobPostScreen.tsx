import { useState } from 'react';
import { ArrowLeft, Briefcase, CheckCircle } from 'lucide-react';

interface JobPostScreenProps {
  onBack: () => void;
}

export default function JobPostScreen({ onBack }: JobPostScreenProps) {
  const [formData, setFormData] = useState({
    title: '',
    type: 'Full Time',
    minSalary: '',
    maxSalary: '',
    description: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        title: '',
        type: 'Full Time',
        minSalary: '',
        maxSalary: '',
        description: '',
      });
    }, 2000);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 text-center">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6">
          <CheckCircle size={48} className="text-green-500" />
        </div>
        <h2 className="mb-3">Job Posted Successfully!</h2>
        <p className="text-gray-600 mb-8">
          Your job listing is now live and visible to job seekers
        </p>
        <button
          onClick={onBack}
          className="px-8 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600"
        >
          Back to Dashboard
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-200 p-4">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 -ml-2 hover:bg-gray-100 rounded-lg">
            <ArrowLeft size={24} />
          </button>
          <h2>Post a Job</h2>
        </div>
      </div>

      {/* Info Banner */}
      <div className="p-4 bg-yellow-50 border-b border-yellow-100">
        <div className="flex items-start gap-3">
          <Briefcase size={20} className="text-yellow-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-yellow-800">
            Post job openings to attract local talent. Jobs are visible to all users in your
            area.
          </p>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        {/* Job Title */}
        <div>
          <label className="block mb-2 text-gray-700">Job Title</label>
          <input
            type="text"
            placeholder="e.g. Shop Assistant, Delivery Person"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            required
            className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:border-green-500"
          />
        </div>

        {/* Job Type */}
        <div>
          <label className="block mb-2 text-gray-700">Job Type</label>
          <select
            value={formData.type}
            onChange={(e) => setFormData({ ...formData, type: e.target.value })}
            className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:border-green-500"
          >
            <option>Full Time</option>
            <option>Part Time</option>
            <option>Contract</option>
          </select>
        </div>

        {/* Salary Range */}
        <div>
          <label className="block mb-2 text-gray-700">Salary Range (Monthly)</label>
          <div className="grid grid-cols-2 gap-3">
            <input
              type="number"
              placeholder="Min (₹)"
              value={formData.minSalary}
              onChange={(e) => setFormData({ ...formData, minSalary: e.target.value })}
              required
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:border-green-500"
            />
            <input
              type="number"
              placeholder="Max (₹)"
              value={formData.maxSalary}
              onChange={(e) => setFormData({ ...formData, maxSalary: e.target.value })}
              required
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:border-green-500"
            />
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="block mb-2 text-gray-700">Job Description</label>
          <textarea
            placeholder="Describe the role, responsibilities, and requirements..."
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            required
            rows={5}
            className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:border-green-500 resize-none"
          />
        </div>

        {/* Preview */}
        <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
          <h4 className="mb-3 text-gray-700">Preview</h4>
          <div className="space-y-2">
            <div>
              <span className="text-sm text-gray-500">Title: </span>
              <span>{formData.title || 'Not set'}</span>
            </div>
            <div>
              <span className="text-sm text-gray-500">Type: </span>
              <span>{formData.type}</span>
            </div>
            <div>
              <span className="text-sm text-gray-500">Salary: </span>
              <span>
                {formData.minSalary && formData.maxSalary
                  ? `₹${formData.minSalary} - ₹${formData.maxSalary}/month`
                  : 'Not set'}
              </span>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          className="w-full py-4 bg-green-500 text-white rounded-lg hover:bg-green-600"
        >
          Post Job
        </button>
      </form>
    </div>
  );
}
