import { CheckCircle, Home, Phone } from 'lucide-react';

interface ReservationConfirmScreenProps {
  itemName: string;
  onBack: () => void;
  onHome: () => void;
}

export default function ReservationConfirmScreen({
  itemName,
  onBack,
  onHome,
}: ReservationConfirmScreenProps) {
  const reservationDetails = {
    shopName: 'Rajesh Provision Store',
    shopPhone: '+91 98765 43210',
    distance: '0.3 km',
    reservationId: 'RSV' + Math.random().toString(36).substr(2, 9).toUpperCase(),
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Success Message */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6">
          <CheckCircle size={48} className="text-green-500" />
        </div>

        <h1 className="mb-3">Reservation Confirmed!</h1>

        <p className="text-gray-600 mb-8">
          Your reservation for <span className="text-blue-600">{itemName}</span> has been
          confirmed
        </p>

        {/* Reservation Details */}
        <div className="w-full max-w-sm p-6 bg-gray-50 rounded-lg border border-gray-200 mb-8">
          <div className="space-y-4">
            <div>
              <div className="text-sm text-gray-500 mb-1">Reservation ID</div>
              <div>{reservationDetails.reservationId}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500 mb-1">Shop Name</div>
              <div>{reservationDetails.shopName}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500 mb-1">Distance</div>
              <div>{reservationDetails.distance}</div>
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="w-full max-w-sm p-4 bg-blue-50 rounded-lg border border-blue-200 mb-8">
          <p className="text-sm text-blue-900">
            Please call the shop to confirm pickup time and availability
          </p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="p-6 border-t border-gray-200 space-y-3">
        <button
          onClick={() => window.location.href = `tel:${reservationDetails.shopPhone}`}
          className="w-full flex items-center justify-center gap-2 py-4 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
        >
          <Phone size={20} />
          <span>Call Shop</span>
        </button>
        <button
          onClick={onHome}
          className="w-full flex items-center justify-center gap-2 py-4 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
        >
          <Home size={20} />
          <span>Back to Home</span>
        </button>
      </div>
    </div>
  );
}
