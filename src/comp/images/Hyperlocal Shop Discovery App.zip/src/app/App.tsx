import { useState } from 'react';
import { Home, Store } from 'lucide-react';
import UserHomeScreen from './components/UserHomeScreen';
import SearchResultsScreen from './components/SearchResultsScreen';
import ItemDetailScreen from './components/ItemDetailScreen';
import ReservationConfirmScreen from './components/ReservationConfirmScreen';
import JobListingsScreen from './components/JobListingsScreen';
import ShopOwnerOnboarding from './components/ShopOwnerOnboarding';
import InventoryUploadScreen from './components/InventoryUploadScreen';
import JobPostScreen from './components/JobPostScreen';
import ReservationRequestsScreen from './components/ReservationRequestsScreen';

export default function App() {
  const [appMode, setAppMode] = useState<'user' | 'owner'>('user');
  const [currentScreen, setCurrentScreen] = useState('home');
  const [selectedItem, setSelectedItem] = useState<string>('');

  const handleSearch = (query: string) => {
    setSelectedItem(query);
    setCurrentScreen('searchResults');
  };

  const handleItemDetail = (item: string) => {
    setSelectedItem(item);
    setCurrentScreen('itemDetail');
  };

  const handleReservation = () => {
    setCurrentScreen('reservationConfirm');
  };

  const renderUserScreen = () => {
    switch (currentScreen) {
      case 'searchResults':
        return (
          <SearchResultsScreen
            searchQuery={selectedItem}
            onBack={() => setCurrentScreen('home')}
            onItemClick={handleItemDetail}
          />
        );
      case 'itemDetail':
        return (
          <ItemDetailScreen
            itemName={selectedItem}
            onBack={() => setCurrentScreen('searchResults')}
            onReserve={handleReservation}
          />
        );
      case 'reservationConfirm':
        return (
          <ReservationConfirmScreen
            itemName={selectedItem}
            onBack={() => setCurrentScreen('itemDetail')}
            onHome={() => setCurrentScreen('home')}
          />
        );
      case 'jobs':
        return <JobListingsScreen onBack={() => setCurrentScreen('home')} />;
      default:
        return (
          <UserHomeScreen
            onSearch={handleSearch}
            onJobsClick={() => setCurrentScreen('jobs')}
          />
        );
    }
  };

  const renderOwnerScreen = () => {
    switch (currentScreen) {
      case 'inventory':
        return <InventoryUploadScreen onBack={() => setCurrentScreen('home')} />;
      case 'jobPost':
        return <JobPostScreen onBack={() => setCurrentScreen('home')} />;
      case 'requests':
        return <ReservationRequestsScreen onBack={() => setCurrentScreen('home')} />;
      default:
        return (
          <ShopOwnerOnboarding
            onInventoryClick={() => setCurrentScreen('inventory')}
            onJobPostClick={() => setCurrentScreen('jobPost')}
            onRequestsClick={() => setCurrentScreen('requests')}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Mobile App Frame */}
      <div className="max-w-md mx-auto min-h-screen bg-white shadow-2xl relative">
        {/* App Mode Switcher - For Demo Purposes */}
        <div className="fixed top-0 left-0 right-0 bg-gray-100 border-b border-gray-200 z-50 max-w-md mx-auto">
          <div className="flex">
            <button
              onClick={() => {
                setAppMode('user');
                setCurrentScreen('home');
              }}
              className={`flex-1 py-3 flex items-center justify-center gap-2 ${
                appMode === 'user' ? 'bg-white border-b-2 border-blue-500' : ''
              }`}
            >
              <Home size={18} />
              <span>User App</span>
            </button>
            <button
              onClick={() => {
                setAppMode('owner');
                setCurrentScreen('home');
              }}
              className={`flex-1 py-3 flex items-center justify-center gap-2 ${
                appMode === 'owner' ? 'bg-white border-b-2 border-green-500' : ''
              }`}
            >
              <Store size={18} />
              <span>Shop Owner</span>
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="pt-14">
          {appMode === 'user' ? renderUserScreen() : renderOwnerScreen()}
        </div>
      </div>
    </div>
  );
}
